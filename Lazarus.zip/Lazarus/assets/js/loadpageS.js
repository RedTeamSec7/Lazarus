function teamRead() {
    setTimeout(myURL, 5000);
    var result = document.querySelector(".card");
}

function Burp() {
    setTimeout(burpUrl, 5000);
    var results = document.querySelector(".card");
}

function burpUrl() {
    window.open('member/burp.html', name = self);
}


function nmap() {
    setTimeout(nmapUrl, 5000);
    var results = document.querySelector(".card");
}

function nmapUrl() {
    window.open('member/nmap.html', name = self);
}

function metas() {
    setTimeout(metasUrl, 5000);
    var results = document.querySelector(".card");
}

function metasUrl() {
    window.open('member/metas.html', name = self);
}

function presec() {
    setTimeout(presecUrl, 5000);
    var results = document.querySelector(".card");
}

function presecUrl() {
    window.open('member/presec.html', name = self);
}

function wireshark() {
    setTimeout(wiresharkUrl, 5000);
    var results = document.querySelector(".card");
}

function wiresharkUrl() {
    window.open('member/wireshark', name = self);
}

function infosec() {
    setTimeout(infosecUrl, 5000);
    var results = document.querySelector(".card");
}

function infosecUrl() {
    window.open('member/infosec.html', name = self);
}

function linux() {
    setTimeout(linuxUrl, 5000);
    var results = document.querySelector(".card");
}

function linuxUrl() {
    window.open('member/linux-hardening.html', name = self);
}

function network() {
    setTimeout(networkUrl, 5000);
    var results = document.querySelector(".card");
}

function networkUrl() {
    window.open('member/network-pentesting.html', name = self);
}

function web() {
    setTimeout(webUrl, 5000);
    var results = document.querySelector(".card");
}

function webUrl() {
    window.open('member/web-pentes.html', name = self);
}

function soc() {
    setTimeout(socUrl, 5000);
    var results = document.querySelector(".card");
}

function socUrl() {
    window.open('member/soc.html', name = self);
}

function blueteam() {
    setTimeout(blueteamUrl, 5000);
    var results = document.querySelector(".card");
}

function blueteamUrl() {
    window.open('member/soc.html', name = self);
}

function malware() {
    setTimeout(malwareUrl, 5000);
    var results = document.querySelector(".card");
}

function malwareUrl() {
    window.open('member/malware-analysis.html', name = self);
}

function crypto() {
    setTimeout(cryptoUrl, 5000);
    var results = document.querySelector(".card");
}

function cryptoUrl() {
    window.open('member/cryptography.html', name = self);
}

function myURL() {
    window.open('member/redteam.html', name = self);
}

function cyberSec() {
    setTimeout(cyberSecUrl, 6000);
    var results = document.querySelector(".card");
}

function cyberSecUrl() {
    window.open('cybersec-labs/labs.html', name = self);
}